library(dplyr)
library(ggplot2) 
library(ggpubr) 
library(reshape2) 
library(tibble)
library(sf) 
library(tmap) 
library(broom)
library(plotly) 
library(magrittr) 
library(shiny) 
library(rsconnect) 
library(devtools)
library(XML)
source("plots/plots.R")

# Define UI for application
ui <- fluidPage(
    
    # Application title
    titlePanel("COVID-19 in Poland"),
    
    tags$p("Please note that the data are updated irregularly"),
    
    sidebarLayout(
      sidebarPanel (
                     checkboxGroupInput(inputId = "regions", label="Select regions:", choices = regions, selected=regions, inline=F)
                     ),
        mainPanel(
                tabsetPanel(
                  
                tabPanel("1. Number of cases and cumulative number of cases",
                                                            plotOutput("map1")),
                tabPanel("2. Unweighted relative risk (SIR) in time ", "Remark 1: loading plots may take 30-40 seconds", tags$br(),
                                                            plotlyOutput("map2") ),
                tabPanel("3. Unweighted cumulative risk (CSIR) in time", "Remark 1: loading plots may take 30-40 seconds", tags$br(),
                                                            plotlyOutput("map3")),
                tabPanel("4. Testing intensity (CSTR) in time", "Remark 1: loading plots may take 30-40 seconds", tags$br(),
                                                            plotlyOutput("map4")),
                tabPanel("5. Local and global positivity rates (LPR and GPR)", "Remark 1: loading plots may take 30-40 seconds", tags$br(),
                         plotlyOutput("map5")),
                tabPanel("6. Weighted cumulative risk (WCSIR) in time", "Remark 1: loading plots may take 30-40 seconds", tags$br(),
                                                            plotlyOutput("map6")),
                tabPanel("7. Unweighted cumulative safety (1/CSIR) in time", "Remark 1: loading plots may take 30-40 seconds", tags$br(),
                                                            plotlyOutput("map7")),
                tabPanel("8. Weighted cumulative safety (1/WCSIR)", "Remark 1: loading plots may take 30-40 seconds", tags$br(),
                                                            plotlyOutput("map8")),
                tabPanel("9. WCSIR in time along with two CSIR curves", "Remark 1: loading plots may take 30-40 seconds", tags$br(),
                                                            plotlyOutput("map9")),
                tabPanel("10. LPR(t)-LPR(t-1) and GPR(t)-GPR(t-1)", "Remark 1: loading plots may take 30-40 seconds", tags$br(),
                                                             plotlyOutput("map10"),  tags$br(), tableOutput("tab2")  )
            
                
            ) 
        )
    )
)

server <- function(input, output) {
        observeEvent(input$regions,  {
          
          output$map1<-  renderPlot  (          chart1  )
          output$map2<-  renderPlotly(  {ggplotly(ggplot(data=SIR_df[SIR_df$regions %in% input$regions,], 
                                                aes(x=Date, y=SIR, group = regions, colour = regions))+
                                                    geom_line(size=0.5) +
                                                    geom_point( size=1, shape=21, fill="white")+
                                                    theme(axis.text.x=element_text(angle = -90, hjust = 0)))}   )
          output$map3<-  renderPlotly(  {ggplotly(ggplot(data=CSIR_df[CSIR_df$regions %in% input$regions,], 
                                                         aes(x=Date, y=CSIR, group = regions, colour = regions))+
                                                    geom_line(size=0.5) +
                                                    geom_point( size=1, shape=21, fill="white")+
                                                    theme(axis.text.x=element_text(angle = -90, hjust = 0))  )}   )
          output$map4<-  renderPlotly(  {ggplotly(ggplot(data=CSTR_df[CSTR_df$regions %in% input$regions,], 
                                                        aes(x=Date, y=CSTR, group = regions, colour = regions)) +
                                                    geom_line(size=0.5) +
                                                    geom_point( size=1, shape=21, fill="white")+
                                                    theme(axis.text.x=element_text(angle = -90, hjust = 0)))}   )
          output$map5<- renderPlotly(  {ggplotly(ggplot(data=LPR_df[LPR_df$regions %in% input$regions,], 
                                                       aes(x=Date, y=LPR, group=regions, colour=regions ) )+
                                                    geom_line(size=0.5)+
                                                    geom_line(data=GPR_df, aes (x=Date, y=GPR, group=regions, colour=regions), size=1.4)+
                                                    geom_point(size=1,shape=21,fill="white")+
                                                    theme(axis.text.x = element_text(angle=-90, hjust=0) ))}  )
          output$map6<- renderPlotly(  {ggplotly(ggplot(data=WCSIR_df[WCSIR_df$regions %in% input$regions,] , 
                                                        aes(x=Date, y=WCSIR, group = regions, colour = regions))+
                                                    geom_line(size=0.5) +
                                                    geom_point( size=1, shape=21, fill="white")+
                                                    theme(axis.text.x=element_text(angle = -90, hjust = 0)))}  )
          output$map7<- renderPlotly(  {ggplotly(ggplot(data=CSIR_limited_df[CSIR_limited_df$regions %in% input$regions,], 
                                                        aes(x=Date, y=1/CSIR, group = regions, colour = regions)) +
                                                    geom_line(size=0.5) +
                                                    geom_point( size=1, shape=21, fill="white")+
                                                    theme(axis.text.x=element_text(angle = -90, hjust = 0)))}  )
          output$map8<- renderPlotly(  {ggplotly(ggplot(data=WCSIR_df[WCSIR_df$regions %in% input$regions,], 
                                                        aes(x=Date, y=1/WCSIR, group = regions, colour = regions))+
                                                    geom_line(size=0.5) +
                                                    geom_point( size=1, shape=21, fill="white")+
                                                    theme(axis.text.x=element_text(angle = -90, hjust = 0)))}  )
          output$map9<- renderPlotly(  {ggplotly(ggplot(data=WCSIR_df[WCSIR_df$regions %in% input$regions,],
                                                        aes(x=Date, y=WCSIR, group=regions, colour=regions))+
                                                    geom_line()+
                                                    geom_line(data=mdf_sil, aes (x=Date, y=CSIR, group = regions, colour=regions), size=1.4)+
                                                    geom_line(data=mdf_op, aes (x=Date, y=CSIR, group=regions, colour=regions), size=1.4)+
                                                    geom_point(size=1, shape=21, fill="white")+
                                                  theme(axis.text.x=element_text(angle=-90, hjust=0)))}  )
          output$map10<-renderPlotly(  {ggplotly(ggplot(data=LPR_diffs_df[LPR_diffs_df$regions %in% input$regions,], 
                                                        aes(x=Date, y=differences, group=regions, colour=regions ) )+
                                                   geom_line(size=0.5)+
                                                   geom_line(data=GPR_diffs_df, aes (x=Date, y=differences, group=regions, colour=regions), size=1.4)+
                                                   geom_point(size=1,shape=21,fill="white")+
                                                   theme(axis.text.x = element_text(angle=-90, hjust=0) ))}  ) 
        })
  }

# Run the application 
shinyApp(ui = ui, server = server)





