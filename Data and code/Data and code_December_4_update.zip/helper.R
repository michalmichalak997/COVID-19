library(dplyr)
library(ggplot2)
library(ggpubr)
library(reshape2)
library(tibble)
library(sf)
library(tmap)
library(broom)
library(plotly)
library(magrittr)

#Regional labels
regions<- c("1 WRO", "2 BYD", "3 LUB", "4 GOR", "5 LOD", "6 KRA", "7 WAR", "8 OPO", "9 RZE", "10 BIA", "11 GDA", "12 KAT",
            "13 KIE", "14 OLS", "15 POZ", "16 SZC") 

#Population in each region
population<-c(2900163, 2072373, 2108270, 1011592, 2454779, 3410901, 5423168, 982626, 2127164, 1178353, 2343928, 4517635, 1233961, 1422737, 3498733, 1696193) 

#Number of observed cases for administrative regions
series<-read.csv("data/series.csv", sep=";", dec=".", header = TRUE, row.names = 1, check.names = FALSE)
colnames(series)<- as.Date(colnames(series), "%d.%m.%Y" ) 

#Number of tests for administrative regions
tests<-read.csv("data/tests.csv", sep=";", dec=".", header = TRUE, row.names = 1, check.names = FALSE)
colnames(tests)<- as.Date(colnames(tests), "%d.%m.%Y" ) 

#Number of tests for the whole country
poland_tests<- read.csv("data/poland_tests.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)



colnames(poland_tests)<- as.Date(colnames(poland_tests), "%d.%m.%Y" ) #assign dates

#A function to calculate a "cumulated" data frame
cumulate_df = function(cases_){ 
  
  sumc<-data.frame(matrix(ncol=ncol(cases_), nrow=16)) #variable for storing the cumulative observed number of cases for each day and each region
  colnames(sumc) <- colnames(cases_)
  
  for(i in 1:16){ #a dummy variable that will help calculate the cumulative number of cases below
    sumc[i,1]<-cases_[i,1]
  }
  
  for(i in 1:16){ #calculating the cumulative number of cases for each region and each day
    for(j in 2:ncol(cases_)){
      sumc[i,j]<-sumc[i,j-1]+cases_[i,j]
    }
  }
  return (sumc) 
}

#A function to calculate SIR
relrisk = function(series, population){ 
  
  sumj<-colSums(series) #sum the observed number of cases for each day
  ratio<-sumj/sum(population)
  expect<-data.frame(matrix(ncol=ncol(series), nrow=0)) #a variable representing the expected number of cases
  colnames(expect) <- colnames(series)
  
  for(i in 1:16){   #the expected number of cases is calculated as the product between the "ratio" variable and regional population
    for(j in 1:ncol(series)){
      expect[i,j]<-ratio[j]*population[i]
    }
  }
  SMR=series/expect #relative risk is calculated as the proportion between the observed and expected number of cases
  return(SMR)
}

#A function to calculate expected number of cases
expect_cum = function(series, population){ 
  
  sumw<-cumulate_df(series) #we first cumulate the data frame
  ratio<-colSums(sumw)/sum(population) #for each day the ratio is calculated as the proportion between the cumulative sum of observed cases for each day and the total population 
  expect<-data.frame(matrix(ncol=ncol(series), nrow=0)) #a variable representing the expected number of cases 
  colnames(expect) <- colnames(series)
  
  for(i in 1:16){ #the expected number of cases is calculated as the product between the "ratio" variable and regional population
    for(j in 1:ncol(series)){
      expect[i,j]<-population[i]*ratio[j]
    }
  }
  return(expect)
}

#A function to calculate CSIR
relrisk_cum = function(series, population){ 

  sumw<-cumulate_df(series) #we first cumulate the data frame
  ratio<-colSums(sumw)/sum(population) #for each day the ratio is calculated as the proportion between the cumulative sum of observed cases for each day and the total population 
  expect<-data.frame(matrix(ncol=ncol(series), nrow=0)) #a variable representing the expected number of cases 
  colnames(expect) <- colnames(series)

  for(i in 1:16){ #the expected number of cases is calculated as the product between the "ratio" variable and regional population
    for(j in 1:ncol(series)){
      expect[i,j]<-population[i]*ratio[j]
    }
  }
  SMR=sumw/expect #relative risk is calculated as the proportion between the observed and expected number of cases
  return(SMR)
}

#A function to calculate the cumulative sum of observed cases in Poland
sum_cum = function(series){ 
  
  sumj<-colSums(series) #a variable to store 
  
  sumk<-c(sumj[1]) #a dummy variable that will help calculate the cumulative sum
  
  for(i in 2:ncol(series)){ #calculate the cumulative sum of confirmed number of cases
    sumk[i]<-sumk[i-1]+sumj[i]
  }
  return(sumk)
}

#A function to interpolate test intensity between days
interpolate_tests = function (tests_sparse){ 
  
  intercept<-data.frame(matrix(ncol=ncol(tests_sparse), nrow=0)) #a variable representing the intercept between weeks

  for(i in 1:16){ #calculating the intercept for every region
    for(j in 1:(ncol(tests_sparse)-1)){ #the intercept for the last day is not needed
      if(j==1){
        intercept[i,j]<- ((tests_sparse[i,j+1]-tests_sparse[i,j]) )/46 #a 46 day-long difference between 2020-03-26 and 2020-05-11
      }
      else{
         intercept[i,j]<- ((tests_sparse[i,j+1]-tests_sparse[i,j]) )/7 #a standard 7 day-long difference
      }                                           }
  }
     #Calculating the interpolation using the previously calculated intercept for the time period before 2020-05-11
         for (k in 1:45){
           new<-tests_sparse[,1]+intercept[,1]*k
           tests_sparse<-add_column(tests_sparse, new, .after = k)
         }
    
     #Calculating the interpolation using the previously calculated intercept for the time period after 2020-05-11
    l=0
    p=1

      for(j in 47: (ncol(tests_sparse) -1 ) ) {
        for (k in 1:6){
          new<-tests_sparse[,47+l]+intercept[,p+1]*k
          tests_sparse<-add_column(tests_sparse, new, .after = 46+k+l)
        }
    l=l+7
    p=p+1
      }
  return(tests_sparse)
}

#A function to calculate the weighted risk, it takes two arguments: data frames with relative risks (confirmed infections) and relative safety (tests)
weighted_risk = function(risks, tests){ 
  return(risks/tests)
}

#A function to reorder labels associated with regions
reorder = function(region_labels){
 reordered_labels<- c(region_labels[12], 
                      region_labels[8], 
                      region_labels[15], 
                      region_labels[16], 
                      region_labels[13], 
                      region_labels[2], 
                      region_labels[10], 
                      region_labels[1], 
                      region_labels[9], 
                      region_labels[6], 
                      region_labels[11], 
                      region_labels[14], 
                      region_labels[5], 
                      region_labels[7], 
                      region_labels[3], 
                      region_labels[4])
  return(reordered_labels)
}

#Calculating the daily observed number of cases in Poland
dailysum_cases<-colSums(series)
dailysum_cases<-setNames(dailysum_cases, colnames(series))
dailysum_cases <- stack(dailysum_cases)
colnames(dailysum_cases)<- c("Infections", "Date")
dailysum_cases$Date <- as.Date(dailysum_cases$Date)
write.table(dailysum_cases, "dailysum_cases.csv", sep=";", dec=".", row.names=F)

#Calculating the cumulative  number of cases in Poland 
cumulativesum_cases=sum_cum(series)
cumulativesum_cases<-setNames(cumulativesum_cases, colnames(series))
cumulativesum_cases <- stack(cumulativesum_cases)
colnames(cumulativesum_cases)<- c("Infections", "Date")
cumulativesum_cases$Date <- as.Date(cumulativesum_cases$Date)
write.table(cumulativesum_cases, "cumulativesum_cases.csv", sep=";", dec=".", row.names=F)

#Calculating the daily number of tests in Poland
poland_tests_i <- c()
for (i in 2:(ncol(poland_tests))){
  poland_tests_i<-c(poland_tests_i, (poland_tests[i]-poland_tests[i-1]))
}
poland_tests_i <- as.numeric(poland_tests_i)
poland_tests_i<-setNames(poland_tests_i, colnames(poland_tests)[1:(ncol(poland_tests)-1)])
poland_tests_i <- stack(poland_tests_i)
colnames(poland_tests_i)<- c("Tests", "Date")
poland_tests_i$Date <- as.Date(poland_tests_i$Date)
write.table(poland_tests_i, "poland_daily_tests.csv", sep=";", dec=".", row.names=F)

#Calculating the cumulative number of tests in Poland
poland_tests <- stack(poland_tests)
colnames(poland_tests)<- c("Tests", "Date")
poland_tests$Date <- as.Date(poland_tests$Date)
write.table(poland_tests, "poland_cumulative_tests.csv", sep=";", dec=".", row.names=F)

#Calculating SIR
SIR_df_pre<- relrisk(series, population)
SIR_df_pre<-dplyr::mutate(SIR_df_pre, regions)
SIR_df_pre <- SIR_df_pre %>% #remove first days
  dplyr::select(regions, everything())%>%
  dplyr::select(-c("2020-03-04",   "2020-03-05",   "2020-03-06",   "2020-03-07",   "2020-03-08",   "2020-03-09",   "2020-03-10",  "2020-03-11",  "2020-03-12"))
SIR_df <- melt(SIR_df_pre, id.vars="regions", value.name="SIR", variable.name="Date") #transformation to long form

write.table(SIR_df, "SIR_df.csv", sep=";", dec=".", row.names=F)

#Calculating CSIR
CSIR_df_pre<- relrisk_cum(series, population)
CSIR_df_pre<-dplyr::mutate(CSIR_df_pre, regions)
CSIR_df_pre<- CSIR_df_pre %>% #remove first days
  dplyr::select(regions, everything())%>%
  dplyr::select(-c("2020-03-04",   "2020-03-05",   "2020-03-06",   "2020-03-07",   "2020-03-08",   "2020-03-09",   "2020-03-10",  "2020-03-11",  "2020-03-12"))
CSIR_df <- melt(CSIR_df_pre, id.vars="regions", value.name="CSIR", variable.name="Date")
write.table(CSIR_df, "CSIR_df.csv", sep=";", dec=".", row.names=F)

#Calculating CSIR(t)-CSIR(t-1)
CSIR_diffs<-c()
CSIR_<-CSIR_df[209:nrow(CSIR_df),]
for (i in 1:(nrow(CSIR_)-16)){
  CSIR_diffs[i]<-CSIR_[i+16,3]-CSIR_[i,3]
}
CSIR_diffs_df<- data.frame(CSIR_diffs, as.Date(CSIR_$Date[17:(nrow(CSIR_))] ))
colnames(CSIR_diffs_df)<-c("differences", "Date")
CSIR_diffs_df$regions<-regions
write.table(CSIR_diffs_df, "CSIR_diffs_df.csv", sep=";", dec=".", row.names=F)


#Calculating CSTR
CSTR_df_pre <- interpolate_tests(tests)
CSTR_df_pre<- relrisk(CSTR_df_pre,population)
colnames(CSTR_df_pre)<- colnames(series[,23:ncol(series)])
CSTR_df_pre<-dplyr::mutate(CSTR_df_pre, regions)
write.table(CSTR_df_pre, "CSTR_df_pre.csv", sep=";", dec=".", row.names=F)
CSTR_df <- melt(CSTR_df_pre, id.vars="regions", value.name="CSTR", variable.name="Date")
write.table(CSTR_df, "CSTR_df.csv", sep=";", dec=".", row.names=F)

#Calculating CSTR(t)-CSTR(t-1)
CSTR_diffs<-c()
for (i in 1:(nrow(CSTR_df)-16)){
  CSTR_diffs[i]<-CSTR_df[i+16,3]-CSTR_df[i,3]
}

CSTR_diffs_df<- data.frame(CSTR_diffs, as.Date(CSTR_df$Date[17:(nrow(CSTR_df))] ))

colnames(CSTR_diffs_df)<-c("differences", "Date")
CSTR_diffs_df$regions<-regions
write.table(CSTR_diffs_df, "CSTR_diffs_df.csv", sep=";", dec=".", row.names=F)

#Calculating GPR (a bug revealed on November 30: cumulate_df(series[,23:ncol(series)])
GPR_df <- colSums(cumulate_df(series))[23:ncol(series)]/colSums(interpolate_tests(tests)) #Because the tests are provided in cumulative form, we don't need to cumulate them
GPR_df <- stack(GPR_df)
colnames(GPR_df)<- c("GPR", "Date")
GPR_df$Date <- as.Date(GPR_df$Date)
GPR_df$regions<- "global"
write.table(GPR_df, "GPR_df.csv", sep=";", dec=".", row.names=F)

#Calculating GPR(t)-GPR(t-1)
GPR_diffs_df<-c()
for (i in 2:nrow(GPR_df)){
  GPR_diffs_df[i-1]<-GPR_df[i,1]-GPR_df[i-1,1]
}
GPR_diffs_df<- data.frame(GPR_diffs_df, as.Date(GPR_df$Date[2:(nrow(GPR_df))]))
GPR_diffs_df$regions<-"global"
colnames(GPR_diffs_df)<-c("differences", "Date", "regions")
write.table(GPR_diffs_df, "GPR_diffs_df.csv", sep=";", dec=".", row.names=F)

#Calculating LPR
LPR_df_pre <- cumulate_df(series)[,23:ncol(series)]/interpolate_tests(tests)
LPR_df_pre<-dplyr::mutate(LPR_df_pre, regions)
LPR_df <- melt(LPR_df_pre, id.vars="regions", value.name="LPR", variable.name="Date")
write.table(LPR_df, "LPR_df.csv", sep=";", dec=".", row.names=F)

#Calculating LPR(t)-LPR(t-1)
LPR_diffs<-c()
for (i in 1:(nrow(LPR_df)-16)){
  LPR_diffs[i]<-LPR_df[i+16,3]-LPR_df[i,3]
}
LPR_diffs_df<- data.frame(LPR_diffs, as.Date(LPR_df$Date[17:(nrow(LPR_df))] ))
colnames(LPR_diffs_df)<-c("differences", "Date")
LPR_diffs_df$regions<-regions
write.table(LPR_diffs_df, "LPR_diffs_df.csv", sep=";", dec=".", row.names=F)

#Calculating WCSIR
WCSIR_df_pre<- weighted_risk(CSIR_df_pre[,15:(ncol(CSIR_df_pre))], CSTR_df_pre[, -ncol(CSTR_df_pre)]) #division of corresponding matrices
WCSIR_df_pre<-dplyr::mutate(WCSIR_df_pre, regions)
WCSIR_df <- melt(WCSIR_df_pre , id.vars="regions", value.name="WCSIR", variable.name="Date")
write.table(WCSIR_df, "WCSIR_df.csv", sep=";", dec=".", row.names=F)

#Calculating WCSIR(t)-WCSIR(t-1)
WCSIR_diffs<-c()
for (i in 1:(nrow(WCSIR_df)-16)){
  WCSIR_diffs[i]<-WCSIR_df[i+16,3]-WCSIR_df[i,3]
}
WCSIR_diffs_df<- data.frame(WCSIR_diffs, as.Date(WCSIR_df$Date[17:(nrow(WCSIR_df))] ))
colnames(WCSIR_diffs_df)<-c("differences", "Date")
WCSIR_diffs_df$regions<-regions
write.table(WCSIR_diffs_df, "WCSIR_diffs_df.csv", sep=";", dec=".", row.names=F)

#Preparing CSIR curves for comparing with WCSIR - we use only 8 OPO and 12 KAT, but it is possible to uncomment to get all curves

# dfwro<-dplyr::filter(CSIR_df_pre, regions=="1 WRO")
# mdf_wro<- melt(dfwro , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_wro <- mdf_wro[-(1:13),] #from March 26
# write.table(mdf_wro, "mdf_wro.csv", sep=";", dec=".", row.names=F)
# 
# dfbyd<-dplyr::filter(CSIR_df_pre, regions=="2 BYD")
# mdf_byd<- melt(dfbyd , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_byd <- mdf_byd[-(1:13),] #from March 26
# write.table(mdf_byd, "mdf_byd.csv", sep=";", dec=".", row.names=F)
# 
# dflub<-dplyr::filter(CSIR_df_pre, regions=="3 LUB")
# mdf_lub<- melt(dflub , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_lub <- mdf_lub[-(1:13),] #from March 26
# write.table(mdf_lub, "mdf_lub.csv", sep=";", dec=".", row.names=F)
# 
# dfgor<-dplyr::filter(CSIR_df_pre, regions=="4 GOR")
# mdf_gor<- melt(dfgor , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_gor <- mdf_gor[-(1:13),] #from March 26
# write.table(mdf_gor, "mdf_gor.csv", sep=";", dec=".", row.names=F)
# 
# dflod<-dplyr::filter(CSIR_df_pre, regions=="5 LOD")
# mdf_lod<- melt(dflod , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_lod<- mdf_lod[-(1:13),] #from March 26
# write.table(mdf_lod, "mdf_lod.csv", sep=";", dec=".", row.names=F)
# 
# dfkra<-dplyr::filter(CSIR_df_pre, regions=="6 KRA")
# mdf_kra<- melt(dfkra , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_kra <- mdf_kra[-(1:13),] #from March 26
# write.table(mdf_kra, "mdf_kra.csv", sep=";", dec=".", row.names=F)
# 
# dfwar<-dplyr::filter(CSIR_df_pre, regions=="7 WAR")
# mdf_war<- melt(dfwar , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_war <- mdf_war[-(1:13),] #from March 26
# write.table(mdf_war, "mdf_war.csv", sep=";", dec=".", row.names=F)

dfop<-dplyr::filter(CSIR_df_pre, regions=="8 OPO")
mdf_op<- melt(dfop , id.vars="regions", value.name="CSIR", variable.name="Date")
mdf_op <- mdf_op[-(1:13),]   #from March 26
write.table(mdf_op , "mdf_op.csv", sep=";", dec=".", row.names=F)

# dfrze<-dplyr::filter(CSIR_df_pre, regions=="9 RZE")
# mdf_rze<- melt(dfrze , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_rze <- mdf_rze[-(1:13),] #from March 26
# write.table(mdf_rze, "mdf_rze.csv", sep=";", dec=".", row.names=F)
# 
# dfbia<-dplyr::filter(CSIR_df_pre, regions=="10 BIA")
# mdf_bia<- melt(dfbia , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_bia <- mdf_bia[-(1:13),] #from March 26
# write.table(mdf_bia, "mdf_bia.csv", sep=";", dec=".", row.names=F)
# 
# dfgda<-dplyr::filter(CSIR_df_pre, regions=="11 GDA")
# mdf_gda<- melt(dfgda , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_gda <- mdf_gda[-(1:13),] #from March 26
# write.table(mdf_gda, "mdf_gda.csv", sep=";", dec=".", row.names=F)

dfsil<-dplyr::filter(CSIR_df_pre, regions=="12 KAT")
mdf_sil<- melt(dfsil , id.vars="regions", value.name="CSIR", variable.name="Date")
mdf_sil <- mdf_sil[-(1:13),] #from March 26
write.table(mdf_sil, "mdf_sil.csv", sep=";", dec=".", row.names=F)

# dfkie<-dplyr::filter(CSIR_df_pre, regions=="13 KIE")
# mdf_kie<- melt(dfkie , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_kie <- mdf_kie[-(1:13),] #from March 26
# write.table(mdf_kie, "mdf_kie.csv", sep=";", dec=".", row.names=F)
# 
# dfols<-dplyr::filter(CSIR_df_pre, regions=="14 OLS")
# mdf_ols<- melt(dfols , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_ols <- mdf_ols[-(1:13),] #from March 26
# write.table(mdf_ols, "mdf_ols.csv", sep=";", dec=".", row.names=F)
# 
# dfpoz<-dplyr::filter(CSIR_df_pre, regions=="15 POZ")
# mdf_poz<- melt(dfpoz , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_poz <- mdf_poz[-(1:13),] #from March 26
# write.table(mdf_poz, "mdf_poz.csv", sep=";", dec=".", row.names=F)
# 
# dfszc<-dplyr::filter(CSIR_df_pre, regions=="16 SZC")
# mdf_szc<- melt(dfszc , id.vars="regions", value.name="CSIR", variable.name="Date")
# mdf_szc <- mdf_szc[-(1:13),] #from March 26
# write.table(mdf_szc, "mdf_szc.csv", sep=";", dec=".", row.names=F)

#Plotting maps
regions <- st_read("data/regions.shp")

#CSIR regional maps
regions$III_week_CSIR<-reorder(as.numeric(as.character(round(CSIR_df_pre[,15], 2)))) #we start with 26.03
regions$VII_week_CSIR<-reorder(as.numeric(as.character(round(CSIR_df_pre[,43], 2))))
regions$XI_week_CSIR<-reorder(as.numeric(as.character(round(CSIR_df_pre[,71], 2))))
regions$XV_week_CSIR<-reorder(as.numeric(as.character(round(CSIR_df_pre[,99], 2))))
regions$XIX_week_CSIR<-reorder(as.numeric(as.character(round(CSIR_df_pre[,127], 2))))
regions$XXIII_week_CSIR<-reorder(as.numeric(as.character(round(CSIR_df_pre[,155], 2))))

font_size=0.7

CSIR_3_week<- tm_shape(regions) +
  tm_polygons('III_week_CSIR',legend.show = FALSE)+
    tm_text('III_week_CSIR', size=font_size  )

CSIR_7_week<- tm_shape(regions) +
  tm_polygons('VII_week_CSIR',legend.show = FALSE)+
  tm_text('VII_week_CSIR', size=font_size  )

CSIR_11_week<- tm_shape(regions) +
  tm_polygons('XI_week_CSIR',legend.show = FALSE)+
  tm_text('XI_week_CSIR', size=font_size  )

CSIR_15_week<- tm_shape(regions) +
  tm_polygons('XV_week_CSIR',legend.show = FALSE)+
  tm_text('XV_week_CSIR', size=font_size )

CSIR_19_week<- tm_shape(regions) +
  tm_polygons('XIX_week_CSIR',legend.show = FALSE)+
  tm_text('XIX_week_CSIR', size=font_size  )

CSIR_23_week<- tm_shape(regions) +
  tm_polygons('XXIII_week_CSIR',legend.show = FALSE)+
  tm_text('XXIII_week_CSIR', size=font_size  )

#WCSIR regional maps
regions$III_week_WCSIR<-reorder(as.numeric(as.character(round(WCSIR_df_pre[,1], 2))))
regions$VII_week_WCSIR<-reorder(as.numeric(as.character(round(WCSIR_df_pre[,29], 2))))
regions$XI_week_WCSIR<-reorder(as.numeric(as.character(round(WCSIR_df_pre[,57], 2))))
regions$XV_week_WCSIR<-reorder(as.numeric(as.character(round(WCSIR_df_pre[,85], 2))))
regions$XIX_week_WCSIR<-reorder(as.numeric(as.character(round(WCSIR_df_pre[,113], 2))))
regions$XXIII_week_WCSIR<-reorder(as.numeric(as.character(round(WCSIR_df_pre[,141], 2))))

WCSIR_3_week<- tm_shape(regions) +
  tm_polygons('III_week_WCSIR',legend.show = FALSE)+
  tm_text('III_week_WCSIR', size=font_size  )

WCSIR_7_week<- tm_shape(regions) +
  tm_polygons('VII_week_WCSIR',legend.show = FALSE)+
  tm_text('VII_week_WCSIR', size=font_size  )

WCSIR_11_week<- tm_shape(regions) +
  tm_polygons('XI_week_WCSIR',legend.show = FALSE)+
  tm_text('XI_week_WCSIR', size=font_size  )

WCSIR_15_week<- tm_shape(regions) +
  tm_polygons('XV_week_WCSIR',legend.show = FALSE)+
  tm_text('XV_week_WCSIR', size=font_size  )

WCSIR_19_week<- tm_shape(regions) +
  tm_polygons('XIX_week_WCSIR',legend.show = FALSE)+
  tm_text('XIX_week_WCSIR', size=font_size  )

WCSIR_23_week<- tm_shape(regions) +
  tm_polygons('XXIII_week_WCSIR',legend.show = FALSE)+
  tm_text('XXIII_week_WCSIR', size=font_size  )

#CSTR regional maps

regions$III_week_CSTR<-reorder(as.numeric(as.character(round(CSTR_df_pre[,1], 2))))
regions$VII_week_CSTR<-reorder(as.numeric(as.character(round(CSTR_df_pre[,29], 2))))
regions$XI_week_CSTR<-reorder(as.numeric(as.character(round(CSTR_df_pre[,57], 2))))
regions$XV_week_CSTR<-reorder(as.numeric(as.character(round(CSTR_df_pre[,85], 2))))
regions$XIX_week_CSTR<-reorder(as.numeric(as.character(round(CSTR_df_pre[,113], 2))))
regions$XXIII_week_CSTR<-reorder(as.numeric(as.character(round(CSTR_df_pre[,141], 2))))

CSTR_3_week<- tm_shape(regions) +
  tm_polygons('III_week_CSTR',legend.show = FALSE)+
  tm_text('III_week_CSTR', size=font_size  )

CSTR_7_week<- tm_shape(regions) +
  tm_polygons('VII_week_CSTR',legend.show = FALSE)+
  tm_text('VII_week_CSTR', size=font_size  )

CSTR_11_week<- tm_shape(regions) +
  tm_polygons('XI_week_CSTR',legend.show = FALSE)+
  tm_text('XI_week_CSTR', size=font_size  )

CSTR_15_week<- tm_shape(regions) +
  tm_polygons('XV_week_CSTR',legend.show = FALSE)+
  tm_text('XV_week_CSTR', size=font_size  )

CSTR_19_week<- tm_shape(regions) +
  tm_polygons('XIX_week_CSTR',legend.show = FALSE)+
  tm_text('XIX_week_CSTR', size=font_size  )

CSTR_23_week<- tm_shape(regions) +
  tm_polygons('XXIII_week_CSTR',legend.show = FALSE)+
  tm_text('XXIII_week_CSTR', size=font_size  )

#LPR regional maps

regions$III_week_LPR<-reorder(as.numeric(as.character(round(LPR_df_pre[,1]*100, 2))))
regions$VII_week_LPR<-reorder(as.numeric(as.character(round(LPR_df_pre[,29]*100, 2))))
regions$XI_week_LPR<-reorder(as.numeric(as.character(round(LPR_df_pre[,57]*100, 2))))
regions$XV_week_LPR<-reorder(as.numeric(as.character(round(LPR_df_pre[,85]*100, 2))))
regions$XIX_week_LPR<-reorder(as.numeric(as.character(round(LPR_df_pre[,113]*100, 2))))
regions$XXIII_week_LPR<-reorder(as.numeric(as.character(round(LPR_df_pre[,141]*100, 2))))

LPR_3_week<- tm_shape(regions) +
  tm_polygons('III_week_LPR',legend.show = FALSE)+
  tm_text('III_week_LPR', size=font_size  )

LPR_7_week<- tm_shape(regions) +
  tm_polygons('VII_week_LPR',legend.show = FALSE)+
  tm_text('VII_week_LPR', size=font_size  )

LPR_11_week<- tm_shape(regions) +
  tm_polygons('XI_week_LPR',legend.show = FALSE)+
  tm_text('XI_week_LPR', size=font_size  )

LPR_15_week<- tm_shape(regions) +
  tm_polygons('XV_week_LPR',legend.show = FALSE)+
  tm_text('XV_week_LPR', size=font_size  )

LPR_19_week<- tm_shape(regions) +
  tm_polygons('XIX_week_LPR',legend.show = FALSE)+
  tm_text('XIX_week_LPR', size=font_size  )

LPR_23_week<- tm_shape(regions) +
  tm_polygons('XXIII_week_LPR',legend.show = FALSE)+
  tm_text('XXIII_week_LPR', size=font_size  )

#Vector of associated GPR values
GPR_vec<- c( round(GPR_df[1,1]*100, 2), round(GPR_df[29,1]*100, 2), round(GPR_df[57,1]*100, 2),
             round(GPR_df[85,1]*100, 2), round(GPR_df[113,1]*100, 2), round(GPR_df[141,1]*100, 2))

current.mode <- tmap_mode("plot")
# tiff("Poland_maps.tiff", units="in", width = 11.2, height=7, res=300)
# tmap_arrange(
#             CSIR_3_week,CSIR_7_week,CSIR_11_week,CSIR_15_week, CSIR_19_week, CSIR_23_week,
#             CSTR_3_week,CSTR_7_week,CSTR_11_week,CSTR_15_week, CSTR_19_week, CSTR_23_week,
#             LPR_3_week,LPR_7_week,LPR_11_week,LPR_15_week,LPR_19_week, LPR_23_week,
#             WCSIR_3_week,WCSIR_7_week,WCSIR_11_week,WCSIR_15_week,WCSIR_19_week, WCSIR_23_week,
#              ncol=6, nrow=4)
# dev.off()
# tmap_mode(current.mode)

#Legend map

regions$Label<-reorder(CSIR_df_pre$regions)

# tiff("Legend_label_map.tiff", units="in", width = 11.2, height=7, res=300)
#  tm_shape(regions) +
#   tm_polygons('Label', legend.show = FALSE)+
#   tm_text('Label', size=1  )
# dev.off()

#Relationship between CSIR and WCSIR
# plot_list = list()
# for (i in 1:16) {
#   #for (j in 1:16){
#   x12 <- CSIR_df_pre[i, -c(1)]
#   y12 <- WCSIR_df_pre[i, -ncol(WCSIR_df_pre)]
#   x12 <- x12[60:ncol(x12)]
#   y12 <- y12[47:ncol(y12)]
#   date <- colnames(x12)
#   df12 <-data.frame(as.numeric(x12), as.numeric(y12), as.Date(date))
#   colnames(df12) <- c("x", "y", "date")
#   lab_dates <- pretty(df12$date)
#   p<-ggplot(df12,
#             aes(x=x, y=y, color= as.numeric(date)))+
#     geom_point(size=2)+
#     scale_colour_viridis_c("Date",
#                            breaks = as.numeric(lab_dates),
#                            labels = lab_dates,
#                            guide = guide_legend()
#                            )+
#     geom_path()+
#     xlab("CSIR")+
#     ylab("WCSIR")
#   plot_list[[i]] = p
# }

# for (i in 1:16){
#   tiff(paste0("CSIR_WCSIR", i, ".tiff"), units="in", width = 11.2, height=7, res=300)
#    print(plot_list[[i]])
#   dev.off()
# }

# tiff("CSIR_WCSIR.tiff", units="in", width = 11.2, height=7, res=300)
# ggpubr::ggarrange(plot_list[[1]],plot_list[[7]],plot_list[[8]],plot_list[[9]],plot_list[[12]],plot_list[[15]],
#                    nrow=2, ncol=3, labels=c("a", "b", "c", "d", "e", "f"), common.legend = T)
# dev.off()

#Relationship between CSTR and CSIR
# plot_list = list()
# for (i in 1:16) {
#   
#   x12 <- CSTR_df_pre[i,-c(ncol(CSTR_df_pre))]
#   y12 <- CSIR_df_pre[i,-c(1)]
#   
#   x12 <- x12[47:ncol(x12)]
#   y12 <- y12[60:ncol(y12)]
#   date <- colnames(x12)
#   df12 <-data.frame(as.numeric(x12), as.numeric(y12), as.Date(date))
#   colnames(df12) <- c("x", "y", "date")
#   lab_dates <- pretty(df12$date)
#   p<-ggplot(df12,
#             aes(x=x, y=y, color= as.numeric(date)))+
#     geom_point(size=2)+
#     scale_colour_viridis_c("Date",
#                            breaks = as.numeric(lab_dates),
#                            labels = lab_dates,
#                            guide = guide_legend()
#                           )+
#     geom_path()+
#     xlab("CSTR")+
#     ylab("CSIR")
#   plot_list[[i]] = p
# }

# for (i in 1:16){
#   tiff(paste0("CSTR_CSIR", i, ".tiff"), units="in", width = 11.2, height=7, res=300)
#    print(plot_list[[i]])
#   dev.off()
# }

# tiff("CSTR_CSIR.tiff", units="in", width = 11.2, height=7, res=300)
# ggpubr::ggarrange(plot_list[[1]],plot_list[[7]],plot_list[[8]],plot_list[[9]],plot_list[[12]],plot_list[[15]],
#                   nrow=2, ncol=3, labels=c("a", "b", "c", "d", "e", "f"), common.legend = T)
# dev.off()


#Relationship between CSIR and LPR

# plot_list = list()
# for (i in 1:16) {
#   
#   y12 <- LPR_df_pre[i,-c(ncol(LPR_df_pre))]
#   x12 <- CSIR_df_pre[i,-c(1)]
#   
#   y12 <- y12[47:ncol(y12)]
#   x12 <- x12[60:ncol(x12)]
#   date <- colnames(x12)
#   df12 <-data.frame(as.numeric(x12), as.numeric(y12), as.Date(date))
#   colnames(df12) <- c("x", "y", "date")
#   lab_dates <- pretty(df12$date)
#   p<-ggplot(df12,
#             aes(x=x, y=y, color= as.numeric(date)))+
#     geom_point(size=2)+
#     scale_colour_viridis_c("Date",
#                            breaks = as.numeric(lab_dates),
#                            labels = lab_dates,
#                            guide = guide_legend()
#                           )+
#     geom_path()+
#     xlab("CSIR")+
#     ylab("LPR")
#   plot_list[[i]] = p
# }

# for (i in 1:16){
#   tiff(paste0("CSIR_LPR", i, ".tiff"), units="in", width = 11.2, height=7, res=300)
#   print(plot_list[[i]])
#   dev.off()
# }

# tiff("CSIR_LPR.tiff", units="in", width = 11.2, height=7, res=300)
# ggpubr::ggarrange(plot_list[[1]],plot_list[[7]],plot_list[[8]],plot_list[[9]],plot_list[[12]],plot_list[[15]],
#                   nrow=2, ncol=3, labels=c("a", "b", "c", "d", "e", "f"), common.legend = T)
# dev.off()


#Relationship between WCSIR and LPR

# plot_list = list()
# for (i in 1:16) {
#   
#   y12 <- WCSIR_df_pre[i,-c(ncol(WCSIR_df_pre))]
#   x12 <- LPR_df_pre[i,-c(ncol(LPR_df_pre))]
#   
#   y12 <- y12[47:ncol(y12)]
#   x12 <- x12[47:ncol(x12)]
# 
#   date <- colnames(x12)
#   df12 <-data.frame(as.numeric(x12), as.numeric(y12), as.Date(date))
#   colnames(df12) <- c("x", "y", "date")
#   lab_dates <- pretty(df12$date)
#   p<-ggplot(df12,
#             aes(x=x, y=y, color= as.numeric(date)))+
#     geom_point(size=2)+
#     scale_colour_viridis_c("Date",
#                            breaks = as.numeric(lab_dates),
#                            labels = lab_dates,
#                            guide = guide_legend()
#                           )+
#     geom_path()+
#     xlab("LPR")+
#     ylab("WCSIR")
#   plot_list[[i]] = p
# }

# for (i in 1:16){
#   tiff(paste0("LPR_WCSIR", i, ".tiff"), units="in", width = 11.2, height=7, res=300)
#   print(plot_list[[i]])
#   dev.off()
# }

# tiff("LPR_WCSIR.tiff", units="in", width = 11.2, height=7, res=300)
# ggpubr::ggarrange(plot_list[[1]],plot_list[[7]],plot_list[[8]],plot_list[[9]],plot_list[[12]],plot_list[[15]],
#                   nrow=2, ncol=3, labels=c("a", "b", "c", "d", "e", "f"), common.legend = T)
# dev.off()

#Relationship between CSTR and LPR

# plot_list = list()
# for (i in 1:16) {
#   
#   x12 <- CSTR_df_pre[i,-c(ncol(CSTR_df_pre))]
#   y12 <- LPR_df_pre[i,-c(ncol(LPR_df_pre))]
#   
#   y12 <- y12[47:ncol(y12)]
#   x12 <- x12[47:ncol(x12)]
#   
#   date <- colnames(x12)
#   df12 <-data.frame(as.numeric(x12), as.numeric(y12), as.Date(date))
#   colnames(df12) <- c("x", "y", "date")
#   lab_dates <- pretty(df12$date)
#   p<-ggplot(df12,
#             aes(x=x, y=y, color= as.numeric(date)))+
#     geom_point(size=2)+
#     scale_colour_viridis_c("Date",
#                            breaks = as.numeric(lab_dates),
#                            labels = lab_dates,
#                            guide = guide_legend()
#                           )+
#     geom_path()+
#     xlab("CSTR")+
#     ylab("LPR")
#   plot_list[[i]] = p
# }

# for (i in 1:16){
#   tiff(paste0("CSTR_LPR", i, ".tiff"), units="in", width = 11.2, height=7, res=300)
#   print(plot_list[[i]])
#   dev.off()
# }

# tiff("CSTR_LPR.tiff", units="in", width = 11.2, height=7, res=300)
# ggpubr::ggarrange(plot_list[[1]],plot_list[[7]],plot_list[[8]],plot_list[[9]],plot_list[[12]],plot_list[[15]],
#                   nrow=2, ncol=3, labels=c("a", "b", "c", "d", "e", "f"), common.legend = T)
# dev.off()

#Relationship between CSTR and WCSIR

# plot_list = list()
# for (i in 1:16) {
#   
#   x12 <- CSTR_df_pre[i,-c(ncol(CSTR_df_pre))]
#   y12 <- WCSIR_df_pre[i,-c(ncol(WCSIR_df_pre))]
#   
#   y12 <- y12[47:ncol(y12)]
#   x12 <- x12[47:ncol(x12)]
#   
#   date <- colnames(x12)
#   df12 <-data.frame(as.numeric(x12), as.numeric(y12), as.Date(date))
#   colnames(df12) <- c("x", "y", "date")
#   lab_dates <- pretty(df12$date)
#   p<-ggplot(df12,
#             aes(x=x, y=y, color= as.numeric(date)))+
#     geom_point(size=2)+
#     scale_colour_viridis_c("Date",
#                            breaks = as.numeric(lab_dates),
#                            labels = lab_dates,
#                            guide = guide_legend()
#     )+
#     geom_path()+
#     xlab("CSTR")+
#     ylab("WCSIR")
#   plot_list[[i]] = p
# }

# for (i in 1:16){
#   tiff(paste0("CSTR_WCSIR", i, ".tiff"), units="in", width = 11.2, height=7, res=300)
#   print(plot_list[[i]])
#   dev.off()
# }

# tiff("CSTR_WCSIR.tiff", units="in", width = 11.2, height=7, res=300)
# ggpubr::ggarrange(plot_list[[1]],plot_list[[7]],plot_list[[8]],plot_list[[9]],plot_list[[12]],plot_list[[15]],
#                   nrow=2, ncol=3, labels=c("a", "b", "c", "d", "e", "f"), common.legend = T)
# dev.off()

#Relationship between GPR and LPR

# plot_list = list()
# for (i in 1:16) {
#   
#   x12 <- GPR_df[,1]
#   y12 <- LPR_df_pre[i,-c(ncol(LPR_df_pre))]
#   
#   y12 <- y12[47:ncol(y12)]
#   x12 <- x12[47:length(x12)]
#   
#   date <- colnames(y12)
#   df12 <-data.frame(as.numeric(x12), as.numeric(y12), as.Date(date))
#   colnames(df12) <- c("x", "y", "date")
#   lab_dates <- pretty(df12$date)
#   p<-ggplot(df12,
#             aes(x=x, y=y, color= as.numeric(date)))+
#     geom_point(size=2)+
#     scale_colour_viridis_c("Date",
#                            breaks = as.numeric(lab_dates),
#                            labels = lab_dates,
#                            guide = guide_legend()
#     )+
#     geom_path()+
#     xlab("GPR")+
#     ylab("LPR")
#   plot_list[[i]] = p
# }

# for (i in 1:16){
#   tiff(paste0("GPR_LPR", i, ".tiff"), units="in", width = 11.2, height=7, res=300)
#   print(plot_list[[i]])
#   dev.off()
# }

# tiff("GPR_LPR.tiff", units="in", width = 11.2, height=7, res=300)
# ggpubr::ggarrange(plot_list[[1]],plot_list[[7]],plot_list[[8]],plot_list[[9]],plot_list[[12]],plot_list[[15]],
#                   nrow=2, ncol=3, labels=c("a", "b", "c", "d", "e", "f"), common.legend = T)
# dev.off()

#We test if WCSIR calculated as CSIR/CSTR equals that WCSIR calculated as LPR/GPR
#WCSIR_df_pre[,1:ncol(LPR_df_pre)-1]-LPR_df_pre[,1:ncol(LPR_df_pre)-1]

GPR_daily<-data.frame(matrix(ncol=ncol(LPR_df_pre)-1, nrow=0)) #a variable representing the expected number of cases 
colnames(GPR_daily) <- colnames(LPR_df_pre)[1:ncol(LPR_df_pre)-1]

for(i in 1:16){ #the expected number of cases is calculated as the product between the "ratio" variable and regional population
  for(j in 1:ncol(GPR_daily)){
    GPR_daily[i,j]<-GPR_df$GPR[j]
  }
}
alternativeWCSIR<- WCSIR_df_pre[,1:ncol(LPR_df_pre)-1]-(LPR_df_pre[,1:ncol(LPR_df_pre)-1]/GPR_daily) 
write.table(x = alternativeWCSIR, "alternativeWCSIR.csv", sep = ";" , dec="."  ) 

#Assessing homogeneity
homogeneityCSIR<-c()

homogeneityCSIR<- colSums((cumulate_df(series)-expect_cum(series,population))^2/expect_cum(series,population))

homogeneityCSIR <- stack(homogeneityCSIR)
colnames(homogeneityCSIR)<- c("Homogeneity", "Date")
homogeneityCSIR$Date <- as.Date(colnames(series))

homogeneityCSIR_plot<-ggplot(homogeneityCSIR, aes(Date, Homogeneity, group=1))+ 
  geom_point() + geom_line(colour = "red")+xlab("Date")+ 
  ylab("Heterogeneity")+
  scale_x_date(labels = scales::date_format("%m-%Y"))+
  ggtitle("")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

# tiff("HomogeneityCSIR_A.tiff", units="in", width = 11.2, height=7, res=300)
# homogeneityCSIR_plot
# dev.off()

homogeneityCSIR<-c()

homogeneityCSIR<- colSums((CSIR_df_pre[,2:ncol(CSIR_df_pre)]-1)^2)

homogeneityCSIR <- stack(homogeneityCSIR)
colnames(homogeneityCSIR)<- c("Homogeneity", "Date")
homogeneityCSIR$Date <- as.Date(colnames(CSIR_df_pre[,2:ncol(CSIR_df_pre)]))

homogeneityCSIR_plot<-ggplot(homogeneityCSIR, aes(Date, Homogeneity, group=1))+ 
  geom_point() + geom_line(colour = "red")+xlab("Date")+ 
  ylab("Heterogeneity")+
  scale_x_date(labels = scales::date_format("%m-%Y"))+
  ggtitle("")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

# tiff("HomogeneityCSIR_B.tiff", units="in", width = 11.2, height=7, res=300)
# homogeneityCSIR_plot
# dev.off()


homogeneityWCSIR<-c()

for (j in 1:(ncol(WCSIR_df_pre)-1)){
  homogeneityWCSIR[j]<-sum((WCSIR_df_pre[,j]-1)^2)
}


homogeneityWCSIR<-setNames(homogeneityWCSIR, colnames(WCSIR_df_pre)[1:(ncol(WCSIR_df_pre)-1)])
homogeneityWCSIR <- stack(homogeneityWCSIR)
colnames(homogeneityWCSIR)<- c("Homogeneity", "Date")
homogeneityWCSIR$Date <- as.Date(colnames(WCSIR_df_pre)[1:(ncol(WCSIR_df_pre)-1)])

homogeneityWCSIR_plot<-ggplot(homogeneityWCSIR, aes(Date, Homogeneity, group=1))+ 
  geom_point() + geom_line(colour = "red")+xlab("Date")+ 
  ylab("Homogeneity")+
  scale_x_date(labels = scales::date_format("%m-%Y"))+
  ggtitle("")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

# tiff("HomogeneityWCSIR.tiff", units="in", width = 11.2, height=7, res=300)
# homogeneityWCSIR_plot
# dev.off()






