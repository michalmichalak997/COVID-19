library(dplyr)
library(ggplot2)
library(ggpubr)
library(reshape2)
library(tibble)
library(sf)
library(tmap)
library(broom)
library(plotly)
library(magrittr)

regions<- c("1 WRO", "2 BYD", "3 LUB", "4 GOR", "5 LOD", "6 KRA", "7 WAR", "8 OPO", "9 RZE", "10 BIA", "11 GDA", "12 KAT",
            "13 KIE", "14 OLS", "15 POZ", "16 SZC")

daily_infections<- read.csv("dailysum_cases.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
cumulative_infections<- read.csv("cumulativesum_cases.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
poland_daily_tests<- read.csv("poland_daily_tests.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
poland_cumulative_tests<- read.csv("poland_cumulative_tests.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)

SIR_df<- read.csv("SIR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
CSIR_df<- read.csv("CSIR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
CSTR_df<- read.csv("CSTR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
LPR_df<- read.csv("LPR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
GPR_df<- read.csv("GPR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
WCSIR_df<- read.csv("WCSIR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
CSIR_diffs_df<- read.csv("CSIR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
CSTR_diffs_df<- read.csv("CSTR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
LPR_diffs_df<- read.csv("LPR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
WCSIR_diffs_df<- read.csv("WCSIR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
GPR_diffs_df<- read.csv("GPR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)

#Note that we only use 8 OPO and 12 KAT, it is possible however to uncomment to get all curves

# mdf_wro<- read.csv("mdf_wro.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_byd<- read.csv("mdf_byd.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_lub<- read.csv("mdf_lub.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_gor<- read.csv("mdf_gor.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_lod<- read.csv("mdf_lod.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_kra<- read.csv("mdf_kra.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_war<- read.csv("mdf_war.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
mdf_op<-  read.csv("mdf_op.csv",  sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_rze<- read.csv("mdf_rze.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_bia<- read.csv("mdf_bia.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_gda<- read.csv("mdf_gda.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
mdf_sil<- read.csv("mdf_sil.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_kie<- read.csv("mdf_kie.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_ols<- read.csv("mdf_ols.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_poz<- read.csv("mdf_poz.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_szc<- read.csv("mdf_szc.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)

daily_infections$Date <- as.Date(daily_infections$Date)
cumulative_infections$Date <- as.Date(cumulative_infections$Date)
poland_daily_tests$Date <- as.Date(poland_daily_tests$Date)
poland_cumulative_tests$Date <- as.Date(poland_cumulative_tests$Date)

SIR_df$Date <- as.Date(SIR_df$Date)
CSIR_df$Date <- as.Date(CSIR_df$Date)
CSTR_df$Date <- as.Date(CSTR_df$Date)
LPR_df$Date<-as.Date(LPR_df$Date)
GPR_df$Date<-as.Date(GPR_df$Date)
WCSIR_df$Date <- as.Date(WCSIR_df$Date)

mdf_sil$Date <- as.Date(mdf_sil$Date)
mdf_op$Date <- as.Date(mdf_op$Date)

#Chart for the daily observed  number of cases in Poland 

chart00<-ggplot(daily_infections, aes(Date, Infections, group=1))+ 
  geom_point() + geom_line(colour = "blue")+xlab("Date")+ 
  ylab("Daily infections")+
  scale_x_date(labels = scales::date_format("%m-%Y"))+
  ggtitle("")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

#Chart for the cumulative observed  number of cases in Poland 

chart01<-ggplot(cumulative_infections, aes(Date, Infections, group=1))+ 
  geom_point() + geom_line(colour = "blue")+xlab("Date")+ 
  ylab("Cumulative infections")+
  scale_x_date(labels = scales::date_format("%m-%Y"))+
  ggtitle("")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

chart1<- ggpubr::ggarrange(chart00,chart01, ncol =1, nrow=2, labels=c("a", "b"))

#  tiff("Infections_daily_cumulative.tiff", units="in", width = 11.2, height=7, res=300)
#  ggpubr::ggarrange(chart00,chart01, ncol =1, nrow=2, labels=c("a", "b"))
#  dev.off()
# 
#  tiff("SIR.tiff", units="in", width = 11.2, height=7, res=300)
#  ggplot(data=SIR_df, aes(
#    x=Date,
#    y=SIR,
#    group = regions,
#    colour = regions
#  )
# )+
#    geom_line(size=0.5) +
#   geom_point( size=1, shape=21, fill="white")+
#    theme(axis.text.x=element_text(angle = -90, hjust = 0))
#  dev.off()

 # tiff("CSIR.tiff", units="in", width = 11.2, height=7, res=300)
 # ggplot(data=CSIR_df, aes(
 #   x=Date,
 #   y=CSIR,
 #   group = regions,
 #   colour = regions
 # )
 # )+
 #   geom_line(size=0.5) +
 #   geom_point( size=1, shape=21, fill="white")+
 #   theme(axis.text.x=element_text(angle = -90, hjust = 0))
 # dev.off()

SIR_plot<-ggplot(data=SIR_df, aes(
  x=Date,
  y=SIR,
  group = regions,
  colour = regions
)
)+
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

CSIR_plot<-ggplot(data=CSIR_df, aes(
  x=Date,
  y=CSIR,
  group = regions,
  colour = regions
)
)+
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

 # tiff("SIR_CSIR.tiff", units="in", width = 11.2, height=14, res=300)
 # ggpubr::ggarrange(SIR_plot,CSIR_plot, ncol =1, nrow=2, labels=c("a", "b"))
 # dev.off()

 # tiff("CSTR.tiff", units="in", width = 11.2, height=7, res=300)
 # ggplot(data=CSTR_df, aes(  #Chart presenting relative testing safety
 #   x=Date,
 #   y=CSTR,
 #   group = regions,
 #   colour = regions
 # )
 # ) +
 #   geom_line(size=0.5) +
 #   geom_point( size=1, shape=21, fill="white")+
 #   theme(axis.text.x=element_text(angle = -90, hjust = 0))
 # dev.off()

 # tiff("SAFETY_CSIR.tiff", units="in", width = 11.2, height=7, res=300)
 # ggplot(data=CSIR_df[209:nrow(CSIR_df),], aes(
 #   x=Date,
 #   y=1/CSIR,
 #   group = regions,
 #   colour = regions
 # )
 # ) +
 #   geom_line(size=0.5) +
 #   geom_point( size=1, shape=21, fill="white")+
 #   theme(axis.text.x=element_text(angle = -90, hjust = 0))
 # dev.off()

SAFETY_CSIR_PLOT <-ggplot(data=CSIR_df[209:nrow(CSIR_df),], aes(
  x=Date,
  y=1/CSIR,
  group = regions,
  colour = regions
)
) +
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

 # tiff("SAFETY_WCSIR.tiff", units="in", width = 11.2, height=7, res=300)
 # ggplot(data=WCSIR_df, aes(
 #  x=Date,
 #    y=1/WCSIR,
 #    group = regions,
 #    colour = regions
 #  )
 #  )+
 #    geom_line(size=0.5) +
 #    geom_point( size=1, shape=21, fill="white")+
 #   theme(axis.text.x=element_text(angle = -90, hjust = 0))
 # dev.off()

SAFETY_WCSIR_PLOT<-ggplot(data=WCSIR_df, aes(
  x=Date,
  y=1/WCSIR,
  group = regions,
  colour = regions
)
)+
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

 # tiff("SAFETY.tiff", units="in", width = 11.2, height=14, res=300)
 # ggpubr::ggarrange(SAFETY_CSIR_PLOT, SAFETY_WCSIR_PLOT, ncol =1, nrow=2, labels=c("a", "b"))
 # dev.off()
 # 
 # tiff("WCSIR.tiff", units="in", width = 11.2, height=7, res=300)
 # ggplot(data=WCSIR_df, aes(
 #   x=Date, y=WCSIR, group=regions, colour=regions))+
 #   geom_line()+
 #  geom_line(data=mdf_sil, aes (x=Date, y=CSIR, group = regions, colour=regions), size=1.4)+
 #  geom_line(data=mdf_op, aes (x=Date, y=CSIR, group=regions, colour=regions), size=1.4)+
 #  geom_point(size=1, shape=21, fill="white")+
 #   theme(axis.text.x=element_text(angle=-90, hjust=0))
 # dev.off()
#
#
 # tiff("LPR_GPR.tiff", units="in", width = 11.2, height=7, res=300)
 # ggplot(data=LPR_df,
 #        aes(x=Date, y=LPR, group=regions, colour=regions ) )+
 #   geom_line(size=0.5)+
 #   geom_line(data=GPR_df, aes (x=Date, y=GPR, group=regions, colour=regions), size=1.4)+
 #  geom_point(size=1,shape=21,fill="white")+
 #  theme(axis.text.x = element_text(angle=-90, hjust=0) )+
 #   ylab("LPR and GPR")
 # dev.off()

#Example plot
 ggplotly(
 ggplot(data=LPR_diffs_df,
        aes(x=Date, y=differences, group=regions, colour=regions ) )+
   geom_line(size=0.5)+
   geom_line(data=GPR_diffs_df, aes (x=Date, y=differences, group=regions, colour=regions), size=1.4)+
   geom_point(size=1,shape=21,fill="white")+
   theme(axis.text.x = element_text(angle=-90, hjust=0) )
 )


 #Europe_data
 #1. Read the input file
 #world<-read.csv("world.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
#
# #2. Assure that data on both infection and tests is supplied and that the number of tests is greater than that of infections
# world <-dplyr::filter(world, !is.na(total_tests) & !is.na(total_cases) & total_tests>total_cases )
#
# world <-dplyr::filter(world,
#                       #Asia peaks
#                       date!='2020-06-24' & date!= '2020-08-06' &
#
#                         #Europe peaks
#                         date!='2020-08-04' & date!= '2020-08-21' & date!= '2020-10-02' &
#                         date!= '2020-07-04'& date!= '2020-12-02' & date!= '2020-12-14' &
#                         date!= '2020-03-30' & date!= '2020-03-19'& date!= '2020-04-01' &
#                         date!= '2020-03-27' & date!= '2020-03-18'& date!= '2020-04-12' &
#
#                         #Africa peaks
#                         date!= '2020-04-07'&
#                         date!= '2020-12-01'&
#
#                         #North America peaks
#                         date!= '2020-12-21' &
#
#                         #Oceania peaks
#                         date!= '2020-08-22'& date!= '2020-08-28' & date!= '2020-08-29'&
#                         date!= '2020-09-04'& date!= '2020-09-05' & date!= '2020-09-11'&
#                         date!= '2020-09-12'& date!= '2020-09-18' & date!= '2020-09-19'&
#                         date!= '2020-09-25'& date!= '2020-09-26' & date!= '2020-09-19'&
#                         date!= '2020-10-03'& date!= '2020-10-04' & date!= '2020-10-05'&
#                         date!= '2020-10-09'& date!= '2020-10-10' & date!= '2020-10-16'&
#                         date!= '2020-10-17'& date!= '2020-10-23' & date!= '2020-10-24'&
#                         date!= '2020-10-30'& date!= '2020-11-06' & date!= '2020-11-13'&
#                         date!= '2020-11-14'& date!= '2020-11-20' & date!= '2020-11-21'&
#                         date!= '2020-11-27'& date!= '2020-11-28' & date!= '2020-12-04'&
#                         date!= '2020-12-11'& date!= '2020-07-28' & date!= '2020-07-31'&
#                         date!= '2020-10-31'& date!= '2020-07-11' & date!= '2020-12-05'&
#                         date!= '2020-12-18'& date!= '2020-03-22' & date!= '2020-03-29' &
#                         date!= '2020-12-19'& date!= '2020-12-24' & date!= '2020-12-26' &
#
#                         #South America peaks
#                         date!= '2020-04-20'& date!= '2020-05-29' & date!= '2020-06-30' &
#                         date!= '2020-07-21'& date!= '2020-07-25' & date!= '2020-08-02' &
#                         date!= '2020-08-08'& date!= '2020-08-15' & date!= '2020-08-31' &
#                         date!= '2020-06-02'& date!= '2020-06-07' & date!= '2020-06-11' &
#                         date!= '2020-06-14'& date!= '2020-06-15' & date!= '2020-06-16' &
#                         date!= '2020-06-17'& date!= '2020-06-18' & date!= '2020-06-21'
# )
#
# #3. Select countries from Europe
# world <-dplyr::filter(world, continent=='Europe')
#
# #4. Calculate local positivity
# world$local_positivity<-world$total_cases/world$total_tests
#
# #5. Subset the data frame with needed columns
# world <-dplyr::select(world, c("continent", "location", "date", "total_tests", "total_cases", "local_positivity", "population") )
#
# #6. Sort the data frame by date rather than by countries
# world<- world[order(world$date),]
#
#
# #7. Determine the time period
# date_range<-unique(world$date)
#
# #8. Prepare empty vectors for global positivity, number of countries
# #for which data are available for each individual day, and
# #global ratios needed for calculating the expected number of cases and tests
#
# global_ratio <- c()
# number_countries <- c()
# r_cases <- c()
# r_tests <- c()
#
#
# for (k in date_range){ #for each date
#   date_index <- which(world$date==k) #get row indices
#   number_countries[k] <- length(date_index) #get number of countries
#   global_ratio[k] <- sum(  world$total_cases[date_index]    )/ sum(  world$total_tests[date_index]    ) #calculate global positivity
#   r_cases[k] <-  sum(  world$total_cases[date_index]    )/sum(  world$population[date_index]    ) #calculate ratio for calculating the expected number of tests
#   r_tests[k] <-  sum(  world$total_tests[date_index]    )/sum(  world$population[date_index]    ) #calculate ratio for calculating the expected number of cases
# }
#
# #9. Replicate global positivity with respect to the number of countries with a given date
# global_positivity <- rep(global_ratio, number_countries)
#
# #10. Replicate ratios to calculated expected number of cases and tests with respect to the number of countries with a given date
# r_cases <- rep (r_cases, number_countries )
# r_tests <- rep (r_tests, number_countries )
#
# #11. Assign global positivity as a new column of the data frame
# world$global_positivity <- global_positivity
#
# #12. Assign WCSIR as a new column of the data frame
# world$WCSIR <-world$local_positivity/world$global_positivity
#
# #13. Assign global ratio for calculating the expected number of cases as a new column of the data frame
# world$r_cases <- r_cases
#
# #14. Assign global ratio for calculating the expected number of tests as a new column of the data frame
# world$r_tests <- r_tests
#
# #15. Assign  expected number of cases as a new column of the data frame
# world$expected_cases <- world$r_cases*world$population
#
# #16. Assign  expected number of tests as a new column of the data frame
# world$expected_tests <- world$r_tests*world$population
#
# #17. Assign CSIR as a new column of the data frame
# world$CSIR <- world$total_cases/world$expected_cases
#
# #18. Assign CSTR as a new column of the data frame
# world$CSTR <- world$total_tests/world$expected_tests
#
# #19. Create empty vectors for homogeneity of CSIR and WCSIR
# homogeneity_CSIR<-c()
# homogeneity_WCSIR<-c()
#
# for (k in date_range){ #for every date
#   date_index <- which(world$date==k) #get row indices
#   homogeneity_CSIR[k] <- sum(  (world$CSTR[date_index]-1)^2    ) #calculate homogeneity of CSIR
#   homogeneity_WCSIR[k] <- sum(  (world$WCSIR[date_index]-1)^2   ) #calculate homogeneity of WCSIR
# }
#
# #20. Transform CSIR into a stack, assign column and date names
# homogeneityCSIR <- stack(homogeneity_CSIR)
# colnames(homogeneityCSIR)<- c("Homogeneity", "Date")
# homogeneityCSIR$Date <- as.Date(unique(world$date))
#
# #21. Generate the plot of CSIR homogeneity
# homogeneityCSIR_plot<-ggplot(homogeneityCSIR, aes(Date, Homogeneity, group=1))+
#   geom_point() + geom_line(colour = "red")+xlab("Date")+
#   ylab("Heterogeneity")+
#   scale_x_date(labels = scales::date_format("%m-%Y"))+
#   ggtitle("")+
#   theme(axis.text.x=element_text(angle = -90, hjust = 0))
#
# homogeneityCSIR_plot
#
# #22. Calculate WCSIR homogeneity
#
# homogeneityWCSIR <- stack(homogeneity_WCSIR)
# colnames(homogeneityWCSIR)<- c("Homogeneity", "Date")
# homogeneityWCSIR$Date <- as.Date(unique(world$date))
#
# #23. Generate the plot of WCSIR homogeneity
# homogeneityWCSIR_plot<-ggplot(homogeneityWCSIR, aes(Date, Homogeneity, group=1))+
#   geom_point() + geom_line(colour = "red")+xlab("Date")+
#   ylab("Heterogeneity")+
#   scale_x_date(labels = scales::date_format("%m-%Y"))+
#   ggtitle("")+
#   theme(axis.text.x=element_text(angle = -90, hjust = 0))
#
# #24. Generate the plot of CSTR
#
# CSTR_plot <- ggplotly(
#   ggplot(data=world, aes(
#     x=date,
#     y=CSTR,
#     group = location,
#     colour = location
#   )
#   )+
#     geom_line(size=0.5) +
#     geom_point( size=1, shape=21, fill="white")+
#     theme(axis.text.x=element_text(angle = -90, hjust = 0))
#
#
# )
#
#
#
# #25. Generate the plot of CSIR
# CSIR_plot <- ggplotly(
#   ggplot(data=world, aes(
#     x=date,
#     y=CSIR,
#     group = location,
#     colour = location
#   )
#   )+
#     geom_line(size=0.5) +
#     geom_point( size=1, shape=21, fill="white")+
#     theme(axis.text.x=element_text(angle = -90, hjust = 0))
#
#
# )
#
#
# #26. Generate the plot of LPR
# LPR_plot<- ggplotly(
#   ggplot(data=world, aes(
#     x=date,
#     y=local_positivity,
#     group = location,
#     colour = location
#   )
#   )+
#     geom_line(size=0.5) +
#     geom_point( size=1, shape=21, fill="white")+
#     theme(axis.text.x=element_text(angle = -90, hjust = 0))
#
#
# )
#
#
# #27. Generate the plot of WCSIR
# WCSIR_plot<- ggplotly(
#   ggplot(data=world, aes(
#     x=date,
#     y=WCSIR,
#     group = location,
#     colour = location
#   )
#   )+
#     geom_line(size=0.5) +
#     geom_point( size=1, shape=21, fill="white")+
#     theme(axis.text.x=element_text(angle = -90, hjust = 0))
# )
#
#
#

















