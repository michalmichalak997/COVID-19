library(dplyr)
library(ggplot2)
library(ggpubr)
library(reshape2)
library(tibble)
library(sf)
library(tmap)
library(broom)
library(plotly)
library(magrittr)

regions<- c("1 WRO", "2 BYD", "3 LUB", "4 GOR", "5 LOD", "6 KRA", "7 WAR", "8 OPO", "9 RZE", "10 BIA", "11 GDA", "12 KAT",
            "13 KIE", "14 OLS", "15 POZ", "16 SZC")

daily_infections<- read.csv("dailysum_cases.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
cumulative_infections<- read.csv("cumulativesum_cases.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
poland_daily_tests<- read.csv("poland_daily_tests.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
poland_cumulative_tests<- read.csv("poland_cumulative_tests.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)

SIR_df<- read.csv("SIR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
CSIR_df<- read.csv("CSIR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
CSTR_df<- read.csv("CSTR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
LPR_df<- read.csv("LPR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
GPR_df<- read.csv("GPR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
WCSIR_df<- read.csv("WCSIR_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
CSIR_diffs_df<- read.csv("CSIR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
CSTR_diffs_df<- read.csv("CSTR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
LPR_diffs_df<- read.csv("LPR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
WCSIR_diffs_df<- read.csv("WCSIR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
GPR_diffs_df<- read.csv("GPR_diffs_df.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)

#Note that we only use 8 OPO and 12 KAT, it is possible however to uncomment to get all curves

# mdf_wro<- read.csv("mdf_wro.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_byd<- read.csv("mdf_byd.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_lub<- read.csv("mdf_lub.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_gor<- read.csv("mdf_gor.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_lod<- read.csv("mdf_lod.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_kra<- read.csv("mdf_kra.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_war<- read.csv("mdf_war.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
mdf_op<-  read.csv("mdf_op.csv",  sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_rze<- read.csv("mdf_rze.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_bia<- read.csv("mdf_bia.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_gda<- read.csv("mdf_gda.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
mdf_sil<- read.csv("mdf_sil.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_kie<- read.csv("mdf_kie.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_ols<- read.csv("mdf_ols.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_poz<- read.csv("mdf_poz.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)
# mdf_szc<- read.csv("mdf_szc.csv", sep=";", dec=".", header = TRUE, check.names = FALSE)

daily_infections$Date <- as.Date(daily_infections$Date)
cumulative_infections$Date <- as.Date(cumulative_infections$Date)
poland_daily_tests$Date <- as.Date(poland_daily_tests$Date)
poland_cumulative_tests$Date <- as.Date(poland_cumulative_tests$Date)

SIR_df$Date <- as.Date(SIR_df$Date)
CSIR_df$Date <- as.Date(CSIR_df$Date)
CSTR_df$Date <- as.Date(CSTR_df$Date)
LPR_df$Date<-as.Date(LPR_df$Date)
GPR_df$Date<-as.Date(GPR_df$Date)
WCSIR_df$Date <- as.Date(WCSIR_df$Date)

mdf_sil$Date <- as.Date(mdf_sil$Date)
mdf_op$Date <- as.Date(mdf_op$Date)

#Chart for the daily observed  number of cases in Poland 

chart00<-ggplot(daily_infections, aes(Date, Infections, group=1))+ 
  geom_point() + geom_line(colour = "blue")+xlab("Date")+ 
  ylab("Daily infections")+
  scale_x_date(labels = scales::date_format("%m-%Y"))+
  ggtitle("")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

#Chart for the cumulative observed  number of cases in Poland 

chart01<-ggplot(cumulative_infections, aes(Date, Infections, group=1))+ 
  geom_point() + geom_line(colour = "blue")+xlab("Date")+ 
  ylab("Cumulative infections")+
  scale_x_date(labels = scales::date_format("%m-%Y"))+
  ggtitle("")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

chart1<- ggpubr::ggarrange(chart00,chart01, ncol =1, nrow=2, labels=c("a", "b"))

tiff("Infections_daily_cumulative.tiff", units="in", width = 11.2, height=7, res=300)
ggpubr::ggarrange(chart00,chart01, ncol =1, nrow=2, labels=c("a", "b"))
dev.off()

tiff("SIR.tiff", units="in", width = 11.2, height=7, res=300)
ggplot(data=SIR_df, aes(
  x=Date,
  y=SIR,
  group = regions,
  colour = regions
)
)+
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))
dev.off()

tiff("CSIR.tiff", units="in", width = 11.2, height=7, res=300)
ggplot(data=CSIR_df, aes(
  x=Date,
  y=CSIR,
  group = regions,
  colour = regions
)
)+
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))
dev.off()

SIR_plot<-ggplot(data=SIR_df, aes(
  x=Date,
  y=SIR,
  group = regions,
  colour = regions
)
)+
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

CSIR_plot<-ggplot(data=CSIR_df, aes(
  x=Date,
  y=CSIR,
  group = regions,
  colour = regions
)
)+
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

tiff("SIR_CSIR.tiff", units="in", width = 11.2, height=14, res=300)
ggpubr::ggarrange(SIR_plot,CSIR_plot, ncol =1, nrow=2, labels=c("a", "b"))
dev.off()

tiff("CSTR.tiff", units="in", width = 11.2, height=7, res=300)
ggplot(data=CSTR_df, aes(  #Chart presenting relative testing safety
  x=Date,
  y=CSTR,
  group = regions,
  colour = regions
)
) +
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))
dev.off()

tiff("SAFETY_CSIR.tiff", units="in", width = 11.2, height=7, res=300)
ggplot(data=CSIR_df[209:nrow(CSIR_df),], aes(
  x=Date,
  y=1/CSIR,
  group = regions,
  colour = regions
)
) +
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))
dev.off()

SAFETY_CSIR_PLOT <-ggplot(data=CSIR_df[209:nrow(CSIR_df),], aes(
  x=Date,
  y=1/CSIR,
  group = regions,
  colour = regions
)
) +
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

tiff("SAFETY_WCSIR.tiff", units="in", width = 11.2, height=7, res=300)
ggplot(data=WCSIR_df, aes(
 x=Date,
   y=1/WCSIR,
   group = regions,
   colour = regions
 )
 )+
   geom_line(size=0.5) +
   geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))
dev.off()

SAFETY_WCSIR_PLOT<-ggplot(data=WCSIR_df, aes(
  x=Date,
  y=1/WCSIR,
  group = regions,
  colour = regions
)
)+
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))

tiff("SAFETY.tiff", units="in", width = 11.2, height=14, res=300)
ggpubr::ggarrange(SAFETY_CSIR_PLOT, SAFETY_WCSIR_PLOT, ncol =1, nrow=2, labels=c("a", "b"))
dev.off()
 
tiff("WCSIR.tiff", units="in", width = 11.2, height=7, res=300)
ggplot(data=WCSIR_df, aes(
  x=Date, y=WCSIR, group=regions, colour=regions))+
  geom_line()+
  geom_line(data=mdf_sil, aes (x=Date, y=CSIR, group = regions, colour=regions), size=1.4)+
  geom_line(data=mdf_op, aes (x=Date, y=CSIR, group=regions, colour=regions), size=1.4)+
  geom_point(size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle=-90, hjust=0))
dev.off()


tiff("LPR_GPR.tiff", units="in", width = 11.2, height=7, res=300)
ggplot(data=LPR_df, 
       aes(x=Date, y=LPR, group=regions, colour=regions ) )+
  geom_line(size=0.5)+
  geom_line(data=GPR_df, aes (x=Date, y=GPR, group=regions, colour=regions), size=1.4)+
  geom_point(size=1,shape=21,fill="white")+
  theme(axis.text.x = element_text(angle=-90, hjust=0) )+
  ylab("LPR and GPR")
dev.off()

#Example plot
ggplotly(
ggplot(data=LPR_diffs_df, 
       aes(x=Date, y=differences, group=regions, colour=regions ) )+
  geom_line(size=0.5)+
  geom_line(data=GPR_diffs_df, aes (x=Date, y=differences, group=regions, colour=regions), size=1.4)+
  geom_point(size=1,shape=21,fill="white")+
  theme(axis.text.x = element_text(angle=-90, hjust=0) )
)












